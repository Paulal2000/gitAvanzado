# Gatling configuration

Use files in this directory to configure Gatling